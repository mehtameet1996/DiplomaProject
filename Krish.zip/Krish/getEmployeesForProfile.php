<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

$emp_name = strval($_GET['e']);
$e = explode(" ", $emp_name);
$sql="SELECT * FROM employee where Emp_FName='".$e[0]."' and Emp_LName='".$e[1]."'";
$result = mysqli_query($mysqli,$sql);
if($row = mysqli_fetch_array($result))
{
?>
<!-- Profile Begins from Here-->
		  
        
        <!-- Widget Row Start grid -->
        <div class="row" id="powerwidgets">
			<div class="col-md-12 bootstrap-grid"> 
            
            <!-- New widget -->
            
            <div class="powerwidget cold-grey" id="profile" data-widget-editbutton="false">
              <header>
                <h2>Profile Page<small>Basic View</small></h2>
              </header>
              <div class="inner-spacer"> 
                
                <!--Profile-->
                  <div class="user-profile-info">
                    <div class="tabs-white">
                      <ul id="myTab" class="nav nav-tabs nav-justified">
                        <li class="active"><a href="#contact" data-toggle="tab">Contact Information</a></li>
                        <li><a href="#employee" data-toggle="tab">Employement Information</a></li>
                      </ul>
                      <div id="myTabContent" class="tab-content">
                        <div class="tab-pane in active" id="contact">
                          <div class="profile-header">Personal Info</div>
                          <table class="table">
                            <tr>
                              <td><strong>Employee ID:</strong></td>
                              <td><?php echo $row['Emp_ID'];?></td>
							  <td><strong>&nbsp;</strong></td>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td><strong>Employee Name:</strong></td>
                              <td><?php echo $row['Emp_FName']." ".$row['Emp_LName'];?></td>
                              <td><strong>Personal Phone:</strong></td>
                              <td><?php echo $row['Emp_Phone'];?></td>
                            </tr>
                            <tr>
                              <td><strong>Personal Email ID:</strong></td>
                              <td><?php echo $row['Emp_Email'];?></td>
                              <td><strong>Alternate Phone:</strong></td>
                              <td><?php echo $row['Emp_Alt_Phone'];?></td>
                            </tr>
                          </table>
                        </div>
                        <div class="tab-pane" id="employee">
                          <div class="profile-header">Employment Info</div>
                          <table class="table">
                            <tr>
                              <td><strong>Employee ID:</strong></td>
                              <td><?php echo $row['Emp_ID'];?></td>
							  <td><strong>Salary:</strong></td>
                              <td><?php echo $row['Emp_Salary'];?></td>
                            </tr>
                            <tr>
                              <td><strong>Employee designation:</strong></td>
                              <td><?php echo $row['Emp_Post'];?></td>
							  <td><strong>&nbsp;</strong></td>
                              <td>&nbsp;</td>
                            </tr>
                            
                          </table>
                        </div>
                        
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <!--/Profile--> 
            </div>
          </div>
          <!-- End .powerwidget --> 
          
        </div>
        <!-- /Inner Row Col-md-12 --> 
      </div>
      <!-- /Widgets Row End Grid--> 
		  
		  <!-- Profile ends here-->
<?php
}
?>