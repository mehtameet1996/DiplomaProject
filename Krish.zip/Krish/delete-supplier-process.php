<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
	//retrieve all information from html page
	$supp_name = strval($_POST['supp_name']);
	$name = explode(" ", $supp_name);
	//Inserting data into database
	$result = mysqli_query($mysqli, "SELECT Supp_ID FROM supplier where Supp_FName='".$name[0]."' and Supp_LName='".$name[1]."'");
	$row = mysqli_fetch_array($result);
	$supp_id=$row['Supp_ID'];
	echo "suppt_id = ".$supp_id;
	if ($insert_stmt = $mysqli->prepare("Delete from supplier  where Supp_ID=?")) 
	{
		$insert_stmt->bind_param('d', $supp_id);
		// Execute the prepared query.
		if ($insert_stmt->execute()) 
		{
			header('Location: customer-success.php');
		}
	}
?>
