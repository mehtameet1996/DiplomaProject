<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

$sql="SELECT * FROM employee";
$result = mysqli_query($mysqli,$sql);
echo"<option value=\"0\" selected disabled>Select Employee Name</option>";
while($row = mysqli_fetch_array($result))
  {
	  
	echo"<option value=\"".$row['Emp_FName']." ".$row['Emp_LName']."\">".$row['Emp_FName']." ".$row['Emp_LName']."</option>";
  }
?>