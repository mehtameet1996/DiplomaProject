<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

$supp_name = strval($_GET['e']);
$s = explode(" ", $supp_name);
$sql="SELECT * FROM supplier where Supp_FName='".$s[0]."' and Supp_LName='".$s[1]."'";
$result = mysqli_query($mysqli,$sql);
$material = array("Paper", "CTP Plates", "Lamination Roll", "Corrugated Boxes", "Wire-O-Clips", "Bubble Wrapping", "Shrink Wrapping");
$count_material = count($material);
if($row = mysqli_fetch_array($result))
{
echo"
<header>Personel Details</header>
<fieldset>
<div class=\"row\">
                      <section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-envelope\"></i>
                          <input type=\"email\" name=\"email\" placeholder=\"E-mail\"  value=".$row['Supp_Email'].">
                        </label>
                      </section>
                      <section class=\"col col-12\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-phone\"></i>
                          <input type=\"tel\" name=\"phone\" placeholder=\"Phone\" value=".$row['Supp_Phone'].">
                        </label>
                      </section>
                    </div>
					<div class=\"row\">
					<section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-fax\"></i>
                          <input type=\"tel\" name=\"fax\" placeholder=\"Fax Number\" value=".$row['Supp_Fax'].">
                        </label>
                      </section>
					<section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-phone\"></i>
                          <input type=\"tel\" name=\"alt_phone\" placeholder=\"Alternate Phone\" value=".$row['Supp_Alt_Phone'].">
                        </label>
                      </section>
                  </fieldset>
                  
				  <fieldset>
				  <header>Business Details</header>
				  <br>
                    <section>
                      <label class=\"input\">
                        <input type=\"text\" name=\"business_name\" placeholder=\"Business Name\" value=".$row['Business_Name'].">
                      </label>
                    </section>
                    <section>
                      <label class=\"input\">
                        <input type=\"text\" name=\"business_address\" placeholder=\"Business Address\" value=".$row['Business_Address'].">
                      </label>
                    </section>
                    <div class=\"row\">
                      <section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-envelope\"></i>
                          <input type=\"business_email\" name=\"b_email\" placeholder=\"Business E-mail\" value=".$row['Business_Email'].">
                        </label>
                      </section>
                      <section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-phone\"></i>
                          <input type=\"tel\" name=\"b_phone\" placeholder=\"Business Phone\" value=".$row['Business_Phone'].">
                        </label>
                      </section>
                    </div>
                  </fieldset>
				  <fieldset>
				  <header>Tax Details</header>
				  <br>
					<fieldset>
						<div class=\"row\">
							<section id=\"input-masking\" class=\"col col-6\">
							  <label class=\"label\">Enter VAT/TIN Number</label>
							  <label class=\"input\"><i class=\"icon-append fa fa-briefcase\"></i>
								<input type=\"text\" id=\"tax\" name=\"tax\" value=".$row['Tax'].">
							  </label>
							</section>
							<section id=\"data-pickers\" class=\"col col-12\">
								<label class=\"label\">wef</label>
								<label class=\"input\"><i class=\"icon-append fa fa-calendar\"></i>
								<input type=\"text\" name=\"date\" id=\"date\" value=".$row['WEF'].">
								</label>
							</section>
						</div>
					</fieldset>
                  </fieldset>
				  <fieldset>
				  <header>Supply Details</header>
				  <br>
					<fieldset>
						<div class=\"row\">
							<section class=\"col col-6\">
							  <label class=\"label\"><b>Select the Materials Supplied</b></label>";
							$sql1="SELECT * FROM raw_materials where Supp_ID=".$row['Supp_ID'];
							$result1 = mysqli_query($mysqli,$sql1);
							  for($i=0;$i<$count_material;$i++)
							  {
								$sql2 = "select * from raw_materials where Supp_ID = ".$row['Supp_ID']." and Material='".$material[$i]."'";
								$result2 = mysqli_query($mysqli, $sql2);
								  if($row2 = mysqli_fetch_array($result2))
								  {
									  echo"<label class=\"toggle\">
										<input type=\"checkbox\" name=\"supply[]\" value='".$material[$i]."' checked>
										<i></i>".$material[$i]."</label>";
								  }
								  else
								  {
									  echo"<label class=\"toggle\">
										<input type=\"checkbox\" name=\"supply[]\" value='".$material[$i]."'>
										<i></i>".$material[$i]."</label>";
								  }
							  }
							  
							echo"</section>
							</div>
							</fieldset>
							<fieldset>
							<div class=\"row\">
							<section class=\"col col-md-6\">
								<label class=\"label\"><b>Rate the Supplier</b></label>
								<div class=\"rating\">";
								for($i=5;$i>0;$i--)
								{
									if($row['Rating']==$i)
									{
										echo"<input type=\"radio\" name=\"rating\" value=".$i." id=\"rating-".$i."\" checked>
										<label for=\"rating-".$i."\"><i class=\"fa fa-star\"></i></label>";
									}
									else
									{
										echo"<input type=\"radio\" name=\"rating\" value=".$i." id=\"rating-".$i."\">
										<label for=\"rating-".$i."\"><i class=\"fa fa-star\"></i></label>";
									}
								}
								echo"Stars</div>
							</section>
						
                  </fieldset>
                  <footer>
                    <button type=\"submit\" class=\"btn btn-warning\">Update Info</button>
                  </footer>";
}
?>