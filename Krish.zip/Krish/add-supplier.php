﻿<!DOCTYPE html>

<head>
<title>White Graphics - Add Suppliers</title>
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
<script type="text/javascript" src="js/vendors/modernizr/modernizr.custom.js"></script>
</head>

<body>

<!--Smooth Scroll-->
<div class="smooth-overflow">
<!--Navigation-->
  <nav class="main-header clearfix" role="navigation"> <a class="navbar-brand" href="index.php"><span class="text-blue">CMS</span></a> 

    <!--Navigation Itself-->
    
    <div class="navbar-content"> 
      <!--Fullscreen Trigger-->
      <button type="button" class="btn btn-default hidden-xs pull-right" id="toggle-fullscreen"> <i class=" entypo-popup"></i> </button>      
    </div>
  </nav>
  
  <!--/Navigation--> 
  
  <!--MainWrapper-->
  <div class="main-wrap"> 
    <!--Main Menu-->
    <div class="responsive-admin-menu">
      <div class="responsive-menu">CMS
        <div class="menuicon"><i class="fa fa-angle-down"></i></div>
      </div>
      <ul id="menu">
        <li><a href="index.php" title="Dashboard">
		<i class="entypo-briefcase"></i><span> Dashboard</span></a></li>
        <li><a class="submenu" href="#" title="Customer" data-id="customers-sub">
			<i class="entypo-users"></i><span> Customers</span></a>
          <ul id="customers-sub">
            <li><a href="add-customers.php" title="Add Customers">
			<i class="entypo-user-add"></i><span> Add Customers</span></a></li>
            <li><a href="delete-customers.php" title="Delete Customers">
			<i class="entypo-cancel-circled"></i><span> Delete Customers</span></a></li>
			<li><a href="update-customers.php" title="Update Customers">
			<i class="entypo-retweet"></i><span> Update Customers</span></a></li>
			<li><a href="view-customers.php" title="View Customers">
			<i class="entypo-user"></i><span> View Customers</span></a></li>
          </ul>
        </li>
        <li><a href="#" class="submenu active" data-id="suppliers-sub" title="Suppliers">
		<i class="fa fa-users"></i><span> Suppliers</span></a> 
          <!-- Tables Sub-Menu -->
          <ul id="suppliers-sub" class="accordion">
            <li><a href="add-supplier.php" title="Add Supplier">
			<i class="entypo-user-add"></i><span> Add Supplier</span></a></li>
            <li><a href="delete-supplier.php" title="Delete Supplier">
			<i class="entypo-cancel-circled"></i><span> Delete Supplier</span></a></li>
			<li><a href="update-supplier.php" title="Update Supplier">
			<i class="entypo-retweet"></i><span> Update Supplier</span></a></li>
			<li><a href="view-suppliers.php" title="View Suppliers">
			<i class="entypo-user"></i><span> View Suppliers</span></a></li>
          </ul>
        </li>
        <li><a class="submenu" href="#" data-id="employee-sub" title="Employee">
		<i class="fa fa-th"></i><span> Employee</span></a> 
          <!-- Forms Sub-Menu -->
          <ul id="employee-sub" class="accordion">
            <li><a href="add-employee.php" title="Add Employee">
			<i class="entypo-user-add"></i><span>Add Employee</span></a></li>
            <li><a href="delete-employee.php" title="Delete Employee">
			<i class="entypo-cancel-circled"></i><span>Delete Employee</span></a></li>
            <li><a href="update-employee.php" title="Update Employee">
			<i class="entypo-retweet"></i><span>Update Employee</span></a></li>
			<li><a href="view-employee.php" title="View Employee">
			<i class="entypo-user"></i><span> View Employee</span></a></li>
          </ul>
        <li> <a href="billing.php" title="Billing">
		<i class="entypo-chart-area"></i><span>Billing</span></a> 
		<li> <a href="send-mail.php" title="Send Mail">
		<i class="entypo-mail"></i><span>send-mail</span></a> 
          <!-- Graph and Charts Menu -->
		</ul>
    </div>
    <!--/MainMenu-->
    
    <div class="content-wrapper"> 
      <!--Content Wrapper--><!--Horisontal Dropdown-->
        <nav class="cbp-hsmenu-wrapper" id="cbp-hsmenu-wrapper">
        </nav>
        
        
          <!--Breadcrumb-->
<div class="breadcrumb clearfix">
            <ul>
              <li><a href="index.php"><i class="fa fa-home"></i></a></li>
              <li><a href="index.php">Dashboard</a></li>
              <li class="active">Add Supplier</li>
            </ul>
          </div>
          <!--/Breadcrumb--> 
          
          <div class="col-md-12 bootstrap-grid">
            
            <!-- New widget -->
            
            <div class="powerwidget green" id="add-customer-form-validation-widget" data-widget-editbutton="false">
              <header>
                <h2>Supplier Registration</h2>
              </header>
              <div class="inner-spacer">
                <form action="http://localhost/krish/add-supplier-process.php" id="add-supplier-form" class="orb-form" method="POST">
                  <header>Personal Details</header>
                  <fieldset>
                    <div class="row">
                      <section class="col col-6">
                        <label class="input"> <i class="icon-prepend fa fa-user"></i>
                          <input type="text" name="fname" placeholder="First name">
                        </label>
                      </section>
                      <section class="col col-6">
                        <label class="input"> <i class="icon-prepend fa fa-user"></i>
                          <input type="text" name="lname" placeholder="Last name">
                        </label>
                      </section>
                    </div>
                    <div class="row">
                      <section class="col col-6">
                        <label class="input"> <i class="icon-prepend fa fa-envelope"></i>
                          <input type="email" name="email" placeholder="E-mail">
                        </label>
                      </section>
                      <section class="col col-6">
                        <label class="input"> <i class="icon-prepend fa fa-phone"></i>
                          <input type="tel" name="phone" placeholder="Phone">
                        </label>
                      </section>
                    </div>
					<div class="row">
					<section class="col col-6">
                        <label class="input"> <i class="icon-prepend fa fa-fax"></i>
                          <input type="tel" name="fax" placeholder="Fax Number">
                        </label>
                      </section>
					<section class="col col-6">
                        <label class="input"> <i class="icon-prepend fa fa-phone"></i>
                          <input type="tel" name="alt_phone" placeholder="Alternate Phone">
                        </label>
                      </section>
                  </fieldset>
                  
				  <fieldset>
				  <header>Business Details</header>
				  <br>
                    <section>
                      <label class="input">
                        <input type="text" name="business_name" placeholder="Business Name">
                      </label>
                    </section>
                    <section>
                      <label class="input">
                        <input type="text" name="business_address" placeholder="Business Address">
                      </label>
                    </section>
                    <div class="row">
                      <section class="col col-6">
                        <label class="input"> <i class="icon-prepend fa fa-envelope"></i>
                          <input type="business_email" name="b_email" placeholder="Business E-mail">
                        </label>
                      </section>
                      <section class="col col-6">
                        <label class="input"> <i class="icon-prepend fa fa-phone"></i>
                          <input type="tel" name="b_phone" placeholder="Business Phone">
                        </label>
                      </section>
                    </div>
                  </fieldset>
				  <fieldset>
				  <header>Tax Details</header>
				  <br>
					<fieldset>
						<div class="row">
							<section id="input-masking" class="col col-6">
							  <label class="label">Enter VAT/TIN Number</label>
							  <label class="input"><i class="icon-append fa fa-briefcase"></i>
								<input type="text" id="tax" name="tax">
							  </label>
							</section>
							<section id="data-pickers" class="col col-12">
								<label class="label">wef</label>
								<label class="input"><i class="icon-append fa fa-calendar"></i>
								<input type="text" name="date" id="date">
								</label>
							</section>
						</div>
					</fieldset>
                  </fieldset>
				  <fieldset>
				  <header>Supply Details</header>
				  <br>
					<fieldset>
						<div class="row">
							<section class="col col-6">
							  <label class="label"><b>Select the Materials Supplied</b></label>
							  <label class="toggle">
								<input type="checkbox" name="supply[]" value="Paper">
								<i></i>Paper</label>
							  <label class="toggle">
								<input type="checkbox" name="supply[]" value="CTP Plates">
								<i></i>CTP Plates</label>
								<label class="toggle">
								<input type="checkbox" name="supply[]" value="Lamination Roll">
								<i></i>Lamination Roll</label>
								<label class="toggle">
								<input type="checkbox" name="supply[]" value="Corrugated Boxes">
								<i></i>Corrugated Boxes</label>
								<label class="toggle">
								<input type="checkbox" name="supply[]" value="Wire-O-Clips">
								<i></i>Wire-O-Clips</label>
								<label class="toggle">
								<input type="checkbox" name="supply[]" value="Bubble Wrapping">
								<i></i>Bubble Wrapping</label>
								<label class="toggle">
								<input type="checkbox" name="supply[]" value="Shrink Wrapping">
								<i></i>Shrink Wrapping</label>
							</section>
							</div>
							</fieldset>
							<fieldset>
							<div class="row">
							<section class="col col-md-6">
								<label class="label"><b>Rate the Supplier</b></label>
								<div class="rating">
								<input type="radio" name="rating" value="5" id="rating-5" >
								<label for="rating-5"><i class="fa fa-star"></i></label>
								<input type="radio" name="stars-rating" id="rating-4" value="4">
								<label for="rating-4"><i class="fa fa-star"></i></label>
								<input type="radio" name="rating" id="rating-3" value="3">
								<label for="rating-3"><i class="fa fa-star"></i></label>
								<input type="radio" name="rating" id="rating-2"value="2">
								<label for="rating-2"><i class="fa fa-star"></i></label>
								<input type="radio" name="rating" id="rating-1" value="1">
								<label for="rating-1"><i class="fa fa-star"></i></label>
								Stars</div>
							</section>
						</div>
					</fieldset>
                  </fieldset>
                  <footer>
                    <button type="submit" class="btn btn-success">Submit</button>
                  </footer>
                </form>
              </div>
            </div>
            <!-- /End Widget --> 
			</div>
        </div>
        </div>
      <!-- / Content Wrapper --> 
    </div>
    <!--/MainWrapper-->
</div>
<!--/Smooth Scroll--> 

<!--Scripts--> 
<!--JQuery--> 
<script type="text/javascript" src="js/vendors/jquery/jquery.min.js"></script> 
<script type="text/javascript" src="js/vendors/jquery/jquery-ui.min.js"></script> 

<script>
$('.powerwidget > header').on('touchstart', function(event){});
</script>

<!--Forms--> 
<script type="text/javascript" src="js/vendors/forms/jquery.form.min.js"></script> 
<script type="text/javascript" src="js/vendors/forms/jquery.validate.min.js"></script> 
<script type="text/javascript" src="js/vendors/forms/jquery.maskedinput.min.js"></script> 
<script type="text/javascript" src="js/vendors/jquery-steps/jquery.steps.min.js"></script> 

<!--Fullscreen--> 
<script type="text/javascript" src="js/vendors/fullscreen/screenfull.min.js"></script> 


<!--Horizontal Dropdown--> 
<script type="text/javascript" src="js/vendors/horisontal/cbpHorizontalSlideOutMenu.js"></script> 
<script type="text/javascript" src="js/vendors/classie/classie.js"></script> 

<!--PowerWidgets--> 
<script type="text/javascript" src="js/vendors/powerwidgets/powerwidgets.min.js"></script> 

<!--Bootstrap--> 
<script type="text/javascript" src="js/vendors/bootstrap/bootstrap.min.js"></script> 

<!--Main App--> 
<script type="text/javascript" src="js/scripts.js"></script>

<!--Sparkline--> 
<script type="text/javascript" src="js/vendors/sparkline/jquery.sparkline.min.js"></script> 

<!--/Scripts-->



<!--/Scripts-->

</body>
</html>