<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

$cust_name = strval($_GET['e']);
$cust = explode(" ", $cust_name);
$sql="SELECT * FROM customers where Cust_FName='".$cust[0]."' and Cust_LName='".$cust[1]."'";
$result = mysqli_query($mysqli,$sql);
if($row = mysqli_fetch_array($result))
{
echo"
<header>Personel Details</header>
<fieldset>
<div class=\"row\">
                      <section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-envelope\"></i>
                          <input type=\"email\" name=\"email\" disabled value=".$row['Cust_Email'].">
                        </label>
                      </section>
                      <section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-phone\"></i>
                          <input type=\"tel\" name=\"phone\" disabled value=".$row['Cust_Phone'].">
                        </label>
                      </section>
                    </div>
					<div class=\"row\">
					<section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-phone\"></i>
                          <input type=\"tel\" name=\"alt_phone\" placeholder=\"Alternate Phone\" disabled value=".$row['Cust_Alt_Phone'].">
                        </label>
                      </section>
			</fieldset>
			<fieldset>
                    <div class=\"row\">
						<section class=\"col col-5\">
							<label class=\"input\">
								<input type=\"text\" name=\"state\" placeholder=\"State\" disabled value=".$row['Cust_State'].">
							</label>
						</section>
                      <section class=\"col col-4\">
                        <label class=\"input\">
                          <input type=\"text\" name=\"city\" placeholder=\"City\" disabled value=".$row['Cust_City'].">
                        </label>
                      </section>
                      <section class=\"col col-3\">
                        <label class=\"input\">
                          <input type=\"text\" name=\"code\" placeholder=\"Post code\" disabled value=".$row['Cust_Code'].">
                        </label>
                      </section>
                    </div>
					
                    <section>
                      <label for=\"file\" class=\"input\">
                        <input type=\"text\" name=\"address\" placeholder=\"Address\" disabled value=\"".htmlspecialchars($row['Cust_Address'])."\">
                      </label>
                    </section>
                    <section>
                      <label class=\"textarea\">
                        <textarea rows=\"3\" name=\"info\" placeholder=\"Additional info\" disabled >".htmlspecialchars($row['Cust_Add_Info'])."</textarea>
                      </label>
                    </section>
                  </fieldset>
				  <fieldset>
				  <header>Business Details</header>
				  <br>
                    <section>
                      <label class=\"input\">
                        <input type=\"text\" name=\"business_name\" placeholder=\"Business Name\" disabled value=".$row['Business_Name'].">
                      </label>
                    </section>
                    <section>
                      <label class=\"input\">
                        <input type=\"text\" name=\"business_address\" placeholder=\"Business Address\" disabled value=".$row['Business_Address'].">
                      </label>
                    </section>
                    <div class=\"row\">
                      <section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-envelope\"></i>
                          <input type=\"business_email\" name=\"b_email\" placeholder=\"Business E-mail\" disabled value=".$row['Business_Email'].">
                        </label>
                      </section>
                      <section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-phone\"></i>
                          <input type=\"tel\" name=\"b_phone\" placeholder=\"Business Phone\" disabled value=".$row['Business_Phone'].">
                        </label>
                      </section>
                    </div>
                  </fieldset>
                  <footer>
                    <button type=\"submit\" class=\"btn btn-danger\">Delete Customer</button>
                  </footer>";
}
?>