<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
	//retrieve all information from html page
	$emp_name = strval($_POST['emp_name']);
	$name = explode(" ", $emp_name);
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$alt_phone = $_POST['alt_phone'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$code = $_POST['code'];
	$address = $_POST['address'];
	$info = $_POST['info'];
	$salary = $_POST['emp_salary'];
	$emp_post = $_POST['emp_post'];
	echo "fname = ".$name[0] ."<br>";
	echo "lname = ".$name[1] ."<br>";
	echo "email = ".$email ."<br>";
	echo "phone = ".$phone ."<br>";
	echo "alt_phone = ".$alt_phone ."<br>";
	echo "state = ".$state ."<br>";
	echo "city = ".$city ."<br>";
	echo "code = ".$code ."<br>";
	echo "address = ".$address ."<br>";
	echo "info = ".$info ."<br>";
	echo "salary = ".$salary ."<br>";
	echo "emp_post = ".$emp_post ."<br>";
	//Inserting data into database
	$result = mysqli_query($mysqli, "SELECT Emp_ID FROM employee where Emp_FName='".$name[0]."' and Emp_LName='".$name[1]."'");
	$row = mysqli_fetch_array($result);
	$emp_id=$row['Emp_ID'];
	echo "emp_id = ".$emp_id;
	if ($insert_stmt = $mysqli->prepare("Update employee set Emp_Email=?, Emp_Phone=?, Emp_Alt_Phone=?, Emp_State=?, Emp_City=?, Emp_Code=?, Emp_Address=?, Emp_Add_Info=?, Emp_Salary=?, Emp_Post=? where Emp_ID=".$emp_id)) 
	{
		$insert_stmt->bind_param('ssssssssss', $email, $phone, $alt_phone, $state, $city, $code, $address, $info, $salary, $emp_post);
		// Execute the prepared query.
		if ($insert_stmt->execute()) 
		{
			header('Location: employee-success.php');
		}
	}
?>
