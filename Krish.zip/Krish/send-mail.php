﻿<!DOCTYPE html>

<head>
<title>White Graphics - Send Mail</title>
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
<script type="text/javascript" src="js/vendors/modernizr/modernizr.custom.js"></script>
</head>

<body>

<!--Smooth Scroll-->
<div class="smooth-overflow">
<!--Navigation-->
  <nav class="main-header clearfix" role="navigation"> <a class="navbar-brand" href="index.php"><span class="text-blue">CMS</span></a> 
   
    <!--Navigation Itself-->
    
    <div class="navbar-content"> 
      <!--Fullscreen Trigger-->
      <button type="button" class="btn btn-default hidden-xs pull-right" id="toggle-fullscreen"> <i class=" entypo-popup"></i> </button>      
    </div>
  </nav>
  
  <!--/Navigation--> 
  
  <!--MainWrapper-->
  <div class="main-wrap"> 
    <!--Main Menu-->
    <div class="responsive-admin-menu">
      <div class="responsive-menu">CMS
        <div class="menuicon"><i class="fa fa-angle-down"></i></div>
      </div>
      <ul id="menu">
        <li><a href="index.php" title="Dashboard">
		<i class="entypo-briefcase"></i><span> Dashboard</span></a></li>
        <li><a class="submenu" href="#" title="Customer" data-id="customers-sub">
			<i class="entypo-users"></i><span> Customers</span></a>
          <ul id="customers-sub">
            <li><a href="add-customers.php" title="Add Customers">
			<i class="entypo-user-add"></i><span> Add Customers</span></a></li>
            <li><a href="delete-customers.php" title="Delete Customers">
			<i class="entypo-cancel-circled"></i><span> Delete Customers</span></a></li>
			<li><a href="update-customers.php" title="Update Customers">
			<i class="entypo-retweet"></i><span> Update Customers</span></a></li>
			<li><a href="view-customers.php" title="View Customers">
			<i class="entypo-user"></i><span> View Customers</span></a></li>
          </ul>
        </li>
        <li><a href="#" class="submenu" data-id="suppliers-sub" title="Suppliers">
		<i class="fa fa-users"></i><span> Suppliers</span></a> 
          <!-- Tables Sub-Menu -->
          <ul id="suppliers-sub" class="accordion">
            <li><a href="add-supplier.php" title="Add Supplier">
			<i class="entypo-user-add"></i><span> Add Supplier</span></a></li>
            <li><a href="delete-supplier.php" title="Delete Supplier">
			<i class="entypo-cancel-circled"></i><span> Delete Supplier</span></a></li>
			<li><a href="update-supplier.php" title="Update Supplier">
			<i class="entypo-retweet"></i><span> Update Supplier</span></a></li>
			<li><a href="view-suppliers.php" title="View Suppliers">
			<i class="entypo-user"></i><span> View Suppliers</span></a></li>
          </ul>
        </li>
        <li><a class="submenu  " href="#" data-id="employee-sub" title="Employee">
		<i class="fa fa-th"></i><span> Employee</span></a> 
          <!-- Forms Sub-Menu -->
          <ul id="employee-sub" class="accordion">
            <li><a href="add-employee.php" title="Add Employee">
			<i class="entypo-user-add"></i><span>Add Employee</span></a></li>
            <li><a href="delete-employee.php" title="Delete Employee">
			<i class="entypo-cancel-circled"></i><span>Delete Employee</span></a></li>
            <li><a href="update-employee.php" title="Update Employee">
			<i class="entypo-retweet"></i><span>Update Employee</span></a></li>
			<li><a href="view-employee.php" title="View Employee">
			<i class="entypo-user"></i><span> View Employee</span></a></li>
          </ul>
        <li> <a href="billing.php" title="Billing">
		<i class="entypo-chart-area"></i><span>Billing</span></a> 
		<li> <a class="active "href="send-mail.php" title="Send Mail">
		<i class="entypo-mail"></i><span>send-mail</span></a> 
          <!-- Graph and Charts Menu -->
		</ul>
    </div>
    <!--/MainMenu-->
    
    <div class="content-wrapper"> 
      <!--Content Wrapper--><!--Horisontal Dropdown-->
        <nav class="cbp-hsmenu-wrapper" id="cbp-hsmenu-wrapper">
        </nav>
        
        
          <!--Breadcrumb-->
<div class="breadcrumb clearfix">
            <ul>
              <li><a href="index.php"><i class="fa fa-home"></i></a></li>
              <li><a href="index.php">Dashboard</a></li>
              <li class="active">Send Mail</li>
            </ul>
          </div>
          <!--/Breadcrumb--> 
          
          <div class="page-header">
			<h1>MIME MAIL SENDING<small>Send Mail</small></h1>
		</div>
		<div class="col-md-12 bootstrap-grid">
            
            <!-- New widget -->
            
            <div class="powerwidget cyan" id="add-employee-form-validation-widget" data-widget-editbutton="false">
              <header>
                <h2>Send Mail</h2>
              </header>
              <div class="inner-spacer">
                <form action="http://localhost/Krish/email.php" id="email-form" method="POST" class="orb-form">
				  <fieldset>
				  <header>Employement Details</header>
				  <br>
				  <section>
                      <label class="input"> <i class="icon-prepend fa fa-envelope"></i>
                        <input type="text" name="from" placeholder="From:">
                      </label>
                  </section>
				  <section>
                      <label class="input"> <i class="icon-prepend fa fa-envelope"></i>
                        <input type="text" name="subject" placeholder="Subject">
                      </label>
                  </section>
                    <section>
                      <label class="input"> <i class="icon-prepend fa fa-envelope"></i>
                        <input type="text" name="to" placeholder="To:">
                      </label>
                    </section>
					<section>
                      <label class="textarea"> <i class="icon-prepend fa fa-code"></i>
                        <textarea rows="10" name="body" placeholder="Body"></textarea>
                      </label>
                    </section>
                  </fieldset>
                  <footer>
                    <button type="submit" class="btn btn-info">Send Mail</button>
                  </footer>
                </form>
              </div>
            </div>
            <!-- /End Widget --> 
			</div>
			
        </div>
      <!-- / Content Wrapper --> 
    </div>
    <!--/MainWrapper-->
</div>
<!--/Smooth Scroll--> 

<!--Scripts--> 
<!--JQuery--> 
<script type="text/javascript" src="js/vendors/jquery/jquery.min.js"></script> 
<script type="text/javascript" src="js/vendors/jquery/jquery-ui.min.js"></script> 

<script>
$('.powerwidget > header').on('touchstart', function(event){});
</script>

<!--Horizontal Dropdown--> 
<script type="text/javascript" src="js/vendors/horisontal/cbpHorizontalSlideOutMenu.js"></script> 
<script type="text/javascript" src="js/vendors/classie/classie.js"></script> 

<!--Fullscreen--> 
<script type="text/javascript" src="js/vendors/fullscreen/screenfull.min.js"></script> 

<!--NanoScroller--> 
<script type="text/javascript" src="js/vendors/nanoscroller/jquery.nanoscroller.min.js"></script> 

<!--Bootstrap--> 
<script type="text/javascript" src="js/vendors/bootstrap/bootstrap.min.js"></script> 

<!--PowerWidgets--> 
<script type="text/javascript" src="js/vendors/powerwidgets/powerwidgets.min.js"></script> 

<!--Forms--> 
<script type="text/javascript" src="js/vendors/forms/jquery.form.min.js"></script> 
<script type="text/javascript" src="js/vendors/forms/jquery.validate.min.js"></script> 
<script type="text/javascript" src="js/vendors/forms/jquery.maskedinput.min.js"></script> 
<script type="text/javascript" src="js/vendors/jquery-steps/jquery.steps.min.js"></script> 

<!--Main App--> 
<script type="text/javascript" src="js/scripts.js"></script>

<!--Sparkline--> 
<script type="text/javascript" src="js/vendors/sparkline/jquery.sparkline.min.js"></script> 

<!--/Scripts-->

</body>
</html>