<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
$flag1= 0;
if(isset($_POST['fname']))
{
	//retrieve all information from html page
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$fax = $_POST['fax'];
	$alt_phone = $_POST['alt_phone'];
	$business_name = $_POST['business_name'];
	$business_address = $_POST['business_address'];
	$b_email = $_POST['b_email'];
	$b_phone = $_POST['b_phone'];
	$tax = $_POST['tax'];
	$wef = $_POST['date'];
	$supply = $_POST['supply'];
	$rating = $_POST['rating'];
	$supply_count = count($supply);
	echo "fname = ".$fname ."<br>";
	echo "lname = ".$lname ."<br>";
	echo "email = ".$email ."<br>";
	echo "phone = ".$phone ."<br>";
	echo "fax = ".$fax ."<br>";
	echo "alt_phone = ".$alt_phone ."<br>";
	echo "business_name = ".$business_name ."<br>";
	echo "business_address = ".$business_address ."<br>";
	echo "b_email = ".$b_email ."<br>";
	echo "b_phone = ".$b_phone ."<br>";
	echo "tax = ".$tax."<br>";
	echo "wef = ".$wef."<br>";
	echo "count = ".$supply_count."<br>";
	for ($i=0; $i<$supply_count; $i++)
		echo $supply[$i]."<br>";
	echo $rating;
	
	//Inserting data into database
	
	$result = mysqli_query($mysqli, "SELECT max(Supp_ID) as id FROM supplier");
	$row = mysqli_fetch_array($result);
	if(is_null($row['id']))
	{
		$Supp_ID=1;
	}
	else
	{	
		$Supp_ID=$row['id'] + 1;
	}
	echo "Supp_ID = ".$Supp_ID;
	if ($insert_stmt = $mysqli->prepare("INSERT INTO supplier VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,? ,?)")) 
	{
		$insert_stmt->bind_param('dsssssssssssss', $Supp_ID, $fname, $lname,$email,$phone,$fax,$alt_phone, $business_name, $business_address, $b_email, $b_phone,$tax, $wef,$rating);
		// Execute the prepared query.
		if ($insert_stmt->execute()) 
		{
			$flag1 = 1;
		}
	}
	
	//inserting araw materials to its table
	for($i=0; $i<$supply_count;$i++)
	{
		if ($insert_stmt = $mysqli->prepare("INSERT INTO raw_materials VALUES (?, ?)")) 
		{
			$insert_stmt->bind_param('ds', $Supp_ID, $supply[$i]);
			// Execute the prepared query.
			if ($insert_stmt->execute()) 
			{
				$flag2 = 1;
			}
		}
	}
	if($flag1==1 && $flag2==1)
		header('Location: supplier-success.php');
}
?>
