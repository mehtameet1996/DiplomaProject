<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

$supp_name = strval($_GET['e']);
$s = explode(" ", $supp_name);
$sql="SELECT * FROM supplier where Supp_FName='".$s[0]."' and Supp_LName='".$s[1]."'";
$result = mysqli_query($mysqli,$sql);
if($row = mysqli_fetch_array($result))
{
?>
<!-- Profile Begins from Here-->
		  
        
        <!-- Widget Row Start grid -->
        <div class="row" id="powerwidgets">
			<div class="col-md-12 bootstrap-grid"> 
            
            <!-- New widget -->
            
            <div class="powerwidget cold-grey" id="profile" data-widget-editbutton="false">
              <header>
                <h2>Profile Page<small>Basic View</small></h2>
              </header>
              <div class="inner-spacer"> 
                
                <!--Profile-->
                  <div class="user-profile-info">
                    <div class="tabs-white">
                      <ul id="myTab" class="nav nav-tabs nav-justified">
                        <li class="active"><a href="#contact" data-toggle="tab">Contact Information</a></li>
                        <li><a href="#business" data-toggle="tab">Business Information</a></li>
                        <li><a href="#tax" data-toggle="tab">Tax Details</a></li>
                        <li><a href="#supply" data-toggle="tab">Supply Details</a></li>
                      </ul>
                      <div id="myTabContent" class="tab-content">
                        <div class="tab-pane in active" id="contact">
                          <div class="profile-header">Personal Info</div>
                          <table class="table">
                            <tr>
                              <td><strong>Supplier ID:</strong></td>
                              <td><?php echo $row['Supp_ID'];?></td>
							  <td><strong>&nbsp;</strong></td>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td><strong>Contact Person:</strong></td>
                              <td><?php echo $row['Supp_FName']." ".$row['Supp_LName'];?></td>
                              <td><strong>Personal Phone:</strong></td>
                              <td><?php echo $row['Supp_Phone'];?></td>
                            </tr>
                            <tr>
                              <td><strong>Personal Email ID:</strong></td>
                              <td><?php echo $row['Supp_Email'];?></td>
                              <td><strong>Alternate Phone:</strong></td>
                              <td><?php echo $row['Supp_Alt_Phone'];?></td>
                            </tr>
                          </table>
                        </div>
                        <div class="tab-pane" id="business">
                          <div class="profile-header">Business Info</div>
                          <table class="table">
                            <tr>
                              <td><strong>Business Name:</strong></td>
                              <td><?php echo $row['Business_Name'];?></td>
							  <td><strong>&nbsp;</strong></td>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td><strong>Business Address:</strong></td>
                              <td><?php echo $row['Business_Address'];?></td>
							  <td><strong>&nbsp;</strong></td>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td><strong>Email ID:</strong></td>
                              <td><?php echo $row['Business_Email'];?></td>
                              <td><strong>Phone:</strong></td>
                              <td><?php echo $row['Business_Phone'];?></td>
                            </tr>
                          </table>
                        </div>
                        <div class="tab-pane" id="tax">
                          <div class="profile-header">Tax Details</div>
                          <table class="table">
                            <tr>
                              <td><strong>VAT No:</strong></td>
                              <td><?php echo $row['Tax']."-V wef:".$row['WEF'];?></td>
							  <td><strong>&nbsp;</strong></td>
                              <td>&nbsp;</td>
                            </tr>
                            <tr>
                              <td><strong>CST/TIN No:</strong></td>
                              <td><?php echo $row['Tax']."-C wef:".$row['WEF'];?></td>
                              <td><strong>&nbsp;</strong></td>
                              <td>&nbsp;</td>
                            </tr>
                          </table>
                        </div>
                        <div class="tab-pane" id="supply">
                          <div class="profile-header">Materials and Rating</div>
                          <table class="table">
						  <?php
							$sql1="SELECT * FROM raw_materials where Supp_ID=".$row['Supp_ID'];
							$result1 = mysqli_query($mysqli,$sql1);
							if($row1 = mysqli_fetch_array($result1))
							{
						  ?>
                            <tr>
								<td><strong>Materials Supplied:</strong></td>
								<td><?php echo $row1['Material']; }?></td>
								<td><strong>&nbsp;</strong></td>
								<td>&nbsp;</td>
                            </tr>
							<?php
							while($row1 = mysqli_fetch_array($result1))
							{
							?>
                            <tr>
                              <td><strong>&nbsp;</strong></td>
                              <td><?php echo $row1['Material']; ?></td>
                              <td><strong>&nbsp;</strong></td>
                              <td>&nbsp;</td>
                            </tr>
							<?php
							}
							?>
							<tr>
								<td><strong>Rating:</strong></td>
								<td><?php echo $row['Rating']." / 5"; ?></td>
								<td><strong>&nbsp;</strong></td>
								<td>&nbsp;</td>
                            </tr>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <!--/Profile--> 
            </div>
          </div>
          <!-- End .powerwidget --> 
          
        </div>
        <!-- /Inner Row Col-md-12 --> 
      </div>
      <!-- /Widgets Row End Grid--> 
		  
		  <!-- Profile ends here-->
<?php
}
?>