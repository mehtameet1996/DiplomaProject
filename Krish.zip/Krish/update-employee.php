﻿<!DOCTYPE html>

<head>
<title>White Graphics - Update Employee</title>
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
<script type="text/javascript" src="js/vendors/modernizr/modernizr.custom.js"></script>
</head>

<body onload="loadEmployees()">

<!--Smooth Scroll-->
<div class="smooth-overflow">
<!--Navigation-->
  <nav class="main-header clearfix" role="navigation"> 
  <a class="navbar-brand" href="index.php"><span class="text-blue">CMS</span></a> 

    <!--Navigation Itself-->
    
    <div class="navbar-content"> 
      <!--Fullscreen Trigger-->
      <button type="button" class="btn btn-default hidden-xs pull-right" id="toggle-fullscreen"> <i class=" entypo-popup"></i> </button>      
    </div>
  </nav>
  
  <!--/Navigation--> 
  
  <!--MainWrapper-->
  <div class="main-wrap"> 
    <!--Main Menu-->
    <div class="responsive-admin-menu">
      <div class="responsive-menu">ORB
        <div class="menuicon"><i class="fa fa-angle-down"></i></div>
      </div>
      <ul id="menu">
        <li><a href="index.php" title="Dashboard">
		<i class="entypo-briefcase"></i><span> Dashboard</span></a></li>
        <li><a class="submenu" href="#" title="Customer" data-id="customers-sub">
			<i class="entypo-users"></i><span> Customers</span></a>
          <ul id="customers-sub">
            <li><a href="add-customers.php" title="Add Customers">
			<i class="entypo-user-add"></i><span> Add Customers</span></a></li>
            <li><a href="delete-customers.php" title="Delete Customers">
			<i class="entypo-cancel-circled"></i><span> Delete Customers</span></a></li>
			<li><a href="update-customers.php" title="Update Customers">
			<i class="entypo-retweet"></i><span> Update Customers</span></a></li>
			<li><a href="view-customers.php" title="View Customers">
			<i class="entypo-user"></i><span> View Customers</span></a></li>
          </ul>
        </li>
        <li><a href="#" class="submenu" data-id="suppliers-sub" title="Suppliers">
		<i class="fa fa-users"></i><span> Suppliers</span></a> 
          <!-- Tables Sub-Menu -->
          <ul id="suppliers-sub" class="accordion">
            <li><a href="add-supplier.php" title="Add Supplier">
			<i class="entypo-user-add"></i><span> Add Supplier</span></a></li>
            <li><a href="delete-supplier.php" title="Delete Supplier">
			<i class="entypo-cancel-circled"></i><span> Delete Supplier</span></a></li>
			<li><a href="update-supplier.php" title="Update Supplier">
			<i class="entypo-retweet"></i><span> Update Supplier</span></a></li>
			<li><a href="view-suppliers.php" title="View Suppliers">
			<i class="entypo-user"></i><span> View Suppliers</span></a></li>
          </ul>
        </li>
        <li><a class="submenu active" href="#" data-id="employee-sub" title="Employee">
		<i class="fa fa-th"></i><span> Employee</span></a> 
          <!-- Forms Sub-Menu -->
          <ul id="employee-sub" class="accordion">
            <li><a href="add-employee.php" title="Add Employee">
			<i class="entypo-user-add"></i><span>Add Employee</span></a></li>
            <li><a href="delete-employee.php" title="Delete Employee">
			<i class="entypo-cancel-circled"></i><span>Delete Employee</span></a></li>
            <li><a href="update-employee.php" title="Update Employee">
			<i class="entypo-retweet"></i><span>Update Employee</span></a></li>
			<li><a href="view-employee.php" title="View Employee">
			<i class="entypo-user"></i><span> View Employee</span></a></li>
          </ul>
        <li> <a href="billing.php" title="Billing">
		<i class="entypo-chart-area"></i><span>Billing</span></a> 
		<li> <a href="send-mail.php" title="Send Mail">
		<i class="entypo-mail"></i><span>send-mail</span></a> 
          <!-- Graph and Charts Menu -->
		</ul>
    </div>
    <!--/MainMenu-->
    
    <div class="content-wrapper"> 
      <!--Content Wrapper--><!--Horisontal Dropdown-->
        <nav class="cbp-hsmenu-wrapper" id="cbp-hsmenu-wrapper">
        </nav>
        
        
          <!--Breadcrumb-->
		<div class="breadcrumb clearfix">
            <ul>
              <li><a href="index.php"><i class="fa fa-home"></i></a></li>
              <li><a href="index.php">Dashboard</a></li>
              <li class="active">Update Employee</li>
            </ul>
          </div>
          <!--/Breadcrumb--> 
			<div class="page-header">
				<h1>Employee<small>Update Employee Detail</small></h1>
			</div>
        
		<div class="powerwidget yellow" id="add-employee-form-validation-widget" data-widget-editbutton="false">
              <header>
                <h2>Update a Employee</h2>
              </header>
              <div class="inner-spacer">
                <form action="update-employee-process.php" name="update-employee-form" id="update-employee-form" class="orb-form" method="POST">
                  <header>Select a Employee</header>
                  <fieldset>
					<div class="row">
						<section class="col col-6">
						<label class="select">
							<select name="emp_name" id="emp_name" onchange="loadDetails()">
								
							</select>
							<i></i> </label>
						</section>
					</div>
                  </fieldset>
				  <div id="details" name="details">
				  </div>
                  
                </form>
              </div>
            </div>
            <!-- /End Widget --> 
			</div>
        </div>
      <!-- / Content Wrapper --> 
    </div>
    <!--/MainWrapper-->
</div>
<!--/Smooth Scroll--> 

<!--Scripts--> 
<!--JQuery--> 
<script type="text/javascript" src="js/vendors/jquery/jquery.min.js"></script> 
<script type="text/javascript" src="js/vendors/jquery/jquery-ui.min.js"></script> 
<script>
   function loadEmployees()
	{
		document.getElementById("emp_name").selectedIndex="None";
		if (window.XMLHttpRequest)
		{// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
		}
		else
		{// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange=function()
		{
			if (xmlhttp.readyState==4 && xmlhttp.status==200)
			{
				document.getElementById("emp_name").innerHTML=xmlhttp.responseText;
			}
		}
		xmlhttp.open("GET","getEmployees.php",true);
		xmlhttp.send();
	}
   </script>
   
   
   <script>
	function loadDetails()
	{
		var selID=document.getElementById("emp_name");
		var employee_name=selID.options[selID.selectedIndex].text;
		document.getElementById("details").selectedIndex="None";
		if (window.XMLHttpRequest)
		{// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
		}
		else
		{// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange=function()
		{
			if (xmlhttp.readyState==4 && xmlhttp.status==200)
			{
				document.getElementById("details").innerHTML=xmlhttp.responseText;
			}
		}
		xmlhttp.open("GET","getEmployeesForUpdate.php?e="+employee_name,true);
		xmlhttp.send();
	}
   </script>
   
 
<script>
$('.powerwidget > header').on('touchstart', function(event){});
</script>

<!--Forms--> 
<script type="text/javascript" src="js/vendors/forms/jquery.form.min.js"></script> 
<script type="text/javascript" src="js/vendors/forms/jquery.validate.min.js"></script> 
<script type="text/javascript" src="js/vendors/forms/jquery.maskedinput.min.js"></script> 
<script type="text/javascript" src="js/vendors/jquery-steps/jquery.steps.min.js"></script> 

<!--Fullscreen--> 
<script type="text/javascript" src="js/vendors/fullscreen/screenfull.min.js"></script> 


<!--Horizontal Dropdown--> 
<script type="text/javascript" src="js/vendors/horisontal/cbpHorizontalSlideOutMenu.js"></script> 
<script type="text/javascript" src="js/vendors/classie/classie.js"></script> 

<!--PowerWidgets--> 
<script type="text/javascript" src="js/vendors/powerwidgets/powerwidgets.min.js"></script> 

<!--Bootstrap--> 
<script type="text/javascript" src="js/vendors/bootstrap/bootstrap.min.js"></script> 

<!--Main App--> 
<script type="text/javascript" src="js/scripts.js"></script>

<!--Sparkline--> 
<script type="text/javascript" src="js/vendors/sparkline/jquery.sparkline.min.js"></script> 

<!--/Scripts-->



<!--/Scripts-->

</body>
</html>