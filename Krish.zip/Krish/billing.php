﻿<!DOCTYPE html>

<head>
<title>White Graphics - Place Order</title>
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
<script type="text/javascript" src="js/vendors/modernizr/modernizr.custom.js"></script>
</head>

<body>

<!--Smooth Scroll-->
<div class="smooth-overflow">
<!--Navigation-->
  <nav class="main-header clearfix" role="navigation"> <a class="navbar-brand" href="index.php"><span class="text-blue">CMS</span></a> 
     
    <!--Navigation Itself-->
    
    <div class="navbar-content"> 
      <!--Fullscreen Trigger-->
      <button type="button" class="btn btn-default hidden-xs pull-right" id="toggle-fullscreen"> <i class=" entypo-popup"></i> </button>      
    </div>
  </nav>
  
  <!--/Navigation--> 
  
  <!--MainWrapper-->
  <div class="main-wrap"> 
    <!--Main Menu-->
    <div class="responsive-admin-menu">
      <div class="responsive-menu">CMS
        <div class="menuicon"><i class="fa fa-angle-down"></i></div>
      </div>
      <ul id="menu">
        <li><a href="index.php" title="Dashboard"><i class="entypo-briefcase"></i><span> Dashboard</span></a></li>
        <li><a class="submenu" href="#" title="Customer" data-id="customers-sub">
			<i class="entypo-users"></i><span> Customers</span></a>
          <ul id="customers-sub">
            <li><a href="add-customers.php" title="Add Customers">
			<i class="entypo-user-add"></i><span> Add Customers</span></a></li>
            <li><a href="delete-customers.php" title="Delete Customers">
			<i class="entypo-cancel-circled"></i><span> Delete Customers</span></a></li>
			<li><a href="update-customers.php" title="Update Customers">
			<i class="entypo-retweet"></i><span> Update Customers</span></a></li>
			<li><a href="view-customers.php" title="View Customers">
			<i class="entypo-user"></i><span> View Customers</span></a></li>
          </ul>
        </li>
        <li><a href="#" class="submenu" data-id="suppliers-sub" title="Suppliers">
		<i class="fa fa-users"></i><span> Suppliers</span></a> 
          <!-- Tables Sub-Menu -->
          <ul id="suppliers-sub" class="accordion">
            <li><a href="add-supplier.php" title="Add Supplier">
			<i class="entypo-user-add"></i><span> Add Supplier</span></a></li>
            <li><a href="delete-supplier.php" title="Delete Supplier">
			<i class="entypo-cancel-circled"></i><span> Delete Supplier</span></a></li>
			<li><a href="update-supplier.php" title="Update Supplier">
			<i class="entypo-retweet"></i><span> Update Supplier</span></a></li>
			<li><a href="view-suppliers.php" title="View Suppliers">
			<i class="entypo-user"></i><span> View Suppliers</span></a></li>
          </ul>
        </li>
        <li><a class="submenu" href="#" data-id="employee-sub" title="Employee">
		<i class="fa fa-th"></i><span> Employee</span></a> 
          <!-- Forms Sub-Menu -->
          <ul id="employee-sub" class="accordion">
            <li><a href="add-employee.php" title="Add Employee">
			<i class="entypo-user-add"></i><span>Add Employee</span></a></li>
            <li><a href="delete-employee.php" title="Delete Employee">
			<i class="entypo-cancel-circled"></i><span>Delete Employee</span></a></li>
            <li><a href="update-employee.php" title="Update Employee">
			<i class="entypo-retweet"></i><span>Update Employee</span></a></li>
			<li><a href="view-employee.php" title="View Employee">
			<i class="entypo-user"></i><span> View Employee</span></a></li>
          </ul>
        <li> <a class="active" href="billing.php" title="Billing">
		<i class="entypo-chart-area"></i><span>Billing</span></a> 
		<li> <a href="send-mail.php" title="Send Mail">
		<i class="entypo-mail"></i><span>send-mail</span></a> 
          <!-- Graph and Charts Menu -->
		</ul>
    </div>
    <!--/MainMenu-->
    
    <div class="content-wrapper"> 
      <!--Content Wrapper--><!--Horisontal Dropdown-->
        <nav class="cbp-hsmenu-wrapper" id="cbp-hsmenu-wrapper">
        </nav>
        
        
          <!--Breadcrumb-->
		<div class="breadcrumb clearfix">
            <ul>
              <li><a href="index.php"><i class="fa fa-home"></i></a></li>
              <li><a href="index.php">Dashboard</a></li>
              <li class="active">Billing</li>
            </ul>
        </div>
        <!--/Breadcrumb-->
		<div class="page-header">
			<h1>Billing<small>Order</small></h1>
		</div>
		
		
			<div class="powerwidget powerwidget-as-portlet-white" id="darkportletdarktable" data-widget-editbutton="false">
			<form action="http://localhost/krish/bill-process.php" id="add-customer-form" class="orb-form" method="POST">
				  <header>
					<label class="input"><i class="icon-prepend fa fa-user"></i>
							  <input type="text" id="cust_name" name="cust_name" placeholder="Customer Name">
							</label>
				  </header>
				  
				  <div class="inner-spacer">
					<table class="table-white table table-striped table-bordered table-hover margin-0px" id="table1">
					  <thead>
						<tr>
						  <th width="40%" colspan="2">Particulars</th>
						  <th width="20%">Quantity</th>
						  <th width="20%">Rate</th>
						  <th width="20%">Amount</th>
						</tr>
					  </thead>
					  <tbody>
						<tr>
						  <td width="1%"><span class="num">1</span></td>
						  <td>
							<label class="input"> <i class="icon-prepend fa fa-user"></i>
							  <input type="text" id="particulars[]" name="particulars[]" placeholder="Particulars">
							</label>
						  </td>
						  <td>
							<label class="input"><i class="icon-prepend fa fa-user"></i>
							  <input type="text" id="quantity[]" value = "0" name="quantity[]" placeholder="Quantity" onchange="calcTotal()">
							</label>
						  </td>
						  <td> 
							<label class="input"><i class="icon-prepend fa fa-user"></i>
							  <input type="text" id="rate[]" name="rate[]" value="0" placeholder="Rate" onchange="calcTotal()">
							</label>
						  </td>
						  <td>
							<label class="input"><i class="icon-prepend fa fa-user"></i>
							  <input type="text" id="amount[]" name="amount[]" placeholder="Amount">
							</label>
						  </td>
						</tr>
					  </tbody>
					</table>
					<footer>
						<button type="button" class="btn btn-primary" value="Add Row" onclick="addRow('table1')">Add Row</button>
						<button type="button" class="btn btn-warning" value="Add Total" onclick="addTotal('table1')">Calculate Total</button>
						<button type="submit" class="btn btn-success">Generate Bill</button>
					  </footer>
				  </div>
				  </form>
				</div>
			
            
            <!-- /New widget --> 
        </div>
      <!-- / Content Wrapper --> 
    </div>
    <!--/MainWrapper-->
</div>
<!--/Smooth Scroll--> 

<!--Scripts--> 
<!--JQuery--> 
<script type="text/javascript" src="js/vendors/jquery/jquery.min.js"></script> 
<script type="text/javascript" src="js/vendors/jquery/jquery-ui.min.js"></script> 

<script>
$('.powerwidget > header').on('touchstart', function(event){});
</script>

<script>
function calcTotal()
{
	var rate = document.getElementsByName("rate[]");
	var len = rate.length;
	var qua = document.getElementsByName("quantity[]");
	for(i=0;i<len;i++)
	{
		var total = Number(rate[i].value) * Number(qua[i].value);
		document.getElementsByName("amount[]")[i].value = total;
	}
}
function addRow(tableID)
{
	var table=document.getElementById(tableID);
	var rowCount=table.rows.length;
	var row=table.insertRow(rowCount);
	var cell1=row.insertCell(0);
	
	cell1.innerHTML="<td width=\"1%\"><span class=\"num\">"+rowCount+"</span></td>";
	var cell2=row.insertCell(1);
	cell2.innerHTML="<label class=\"input\"><i class=\"icon-prepend fa fa-user\"></i><input type=\"text\" id=\"particulars[]\"  name=\"particulars[]\" placeholder=\"Particulars\"></label>";
	var cell3=row.insertCell(2);
	cell3.innerHTML="<label class=\"input\"><i class=\"icon-prepend fa fa-user\"></i><input type=\"text\" id=\"quantity[]\" value=\"0\" name=\"quantity[]\" placeholder=\"Quantity\" onchange=\"calcTotal()\"></label>";
	var cell4=row.insertCell(3);
	cell4.innerHTML="<label class=\"input\"><i class=\"icon-prepend fa fa-user\"></i><input type=\"text\" id=\"rate[]\" value=\"0\" name=\"rate[]\" placeholder=\"Rate\" onchange=\"calcTotal()\"></label>";
	var cell5=row.insertCell(4);
	cell5.innerHTML="<label class=\"input\"><i class=\"icon-prepend fa fa-user\"></i><input type=\"text\" id=\"amount[]\" value=\"0\" name=\"amount[]\" placeholder=\"Amount\"></label>";
}
function addTotal(tableID)
{
	amt = document.getElementsByName("amount[]");
	var total = 0;
	for(var i=0; i<amt.length; i++)
	{
		var a = parseFloat(amt[i].value.replace(/,/g,''));
		total = total + a;
	}
	total = total.toString();
	var afterPoint = '';
	if(total.indexOf('.')>0)
		afterPoint = total.substring(total.indexOf('.'),total.length);
	total = Math.floor(total);
	total = total.toString();
	var lastThree = total.substring(total.length-3);
	var otherNumbers = total.substring(0, total.length-3);
	if(otherNumbers!='')
		lastThree = "," + lastThree;
	var finalTotal = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",")+lastThree+afterPoint;
	var table=document.getElementById(tableID);
	var rowCount=table.rows.length;
	var row=table.insertRow(rowCount);
	
	
	var cell1=row.insertCell(0);
	
	cell1.innerHTML="&nbsp;";
	var cell2=row.insertCell(1);
	cell2.innerHTML="&nbsp;";
	var cell3=row.insertCell(2);
	cell3.innerHTML="&nbsp;";
	
	
	var cell4=row.insertCell(3);
	cell4.innerHTML="Total";
	var cell5=row.insertCell(4);
	cell5.innerHTML="<label class=\"input\"><i class=\"icon-prepend fa fa-user\"></i><input type=\"text\" disabled name=\"total\" value=\""+finalTotal+"\"></label>";
}
function deleteRow(tableID)
{
	try
	{
		var table=document.getElementById(tableID);
		var rowCount=table.rows.length;
		for(var i=0;i<rowCount;i++)
		{
			var row=table.rows[i];
			var chkbox=row.cells[0].childNodes[0];
			if(null!=chkbox&&true==chkbox.checked)
			{
				table.deleteRow(i);
				rowCount--;
				i--;
			}
		}
	}catch(e)
	{
		alert(e);
	}
}
</script> 


<!--Forms--> 
<script type="text/javascript" src="js/vendors/forms/jquery.form.min.js"></script> 
<script type="text/javascript" src="js/vendors/forms/jquery.validate.min.js"></script> 
<script type="text/javascript" src="js/vendors/forms/jquery.maskedinput.min.js"></script> 
<script type="text/javascript" src="js/vendors/jquery-steps/jquery.steps.min.js"></script> 

<!--Fullscreen--> 
<script type="text/javascript" src="js/vendors/fullscreen/screenfull.min.js"></script> 


<!--Horizontal Dropdown--> 
<script type="text/javascript" src="js/vendors/horisontal/cbpHorizontalSlideOutMenu.js"></script> 
<script type="text/javascript" src="js/vendors/classie/classie.js"></script> 

<!--PowerWidgets--> 
<script type="text/javascript" src="js/vendors/powerwidgets/powerwidgets.min.js"></script> 

<!--Bootstrap--> 
<script type="text/javascript" src="js/vendors/bootstrap/bootstrap.min.js"></script> 

<!--Main App--> 
<script type="text/javascript" src="js/scripts.js"></script>

<!--Sparkline--> 
<script type="text/javascript" src="js/vendors/sparkline/jquery.sparkline.min.js"></script> 

<!--/Scripts-->

</body>
</html>