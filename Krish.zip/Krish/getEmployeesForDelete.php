<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

$emp_name = strval($_GET['e']);
$emp = explode(" ", $emp_name);
$sql="SELECT * FROM employee where Emp_FName='".$emp[0]."' and Emp_LName='".$emp[1]."'";
$result = mysqli_query($mysqli,$sql);
if($row = mysqli_fetch_array($result))
{
echo"
<header>Personel Details</header>
<fieldset>
<div class=\"row\">
                      <section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-envelope\"></i>
                          <input type=\"email\" name=\"email\" disabled value=".$row['Emp_Email'].">
                        </label>
                      </section>
                      <section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-phone\"></i>
                          <input type=\"tel\" name=\"phone\" disabled value=".$row['Emp_Phone'].">
                        </label>
                      </section>
                    </div>
					<div class=\"row\">
					<section class=\"col col-6\">
                        <label class=\"input\"> <i class=\"icon-prepend fa fa-phone\"></i>
                          <input type=\"tel\" name=\"alt_phone\" placeholder=\"Alternate Phone\" disabled value=".$row['Emp_Alt_Phone'].">
                        </label>
                      </section>
			</fieldset>
			<fieldset>
                    <div class=\"row\">
						<section class=\"col col-5\">
							<label class=\"input\">
								<input type=\"text\" name=\"state\" placeholder=\"State\" disabled value=".$row['Emp_State'].">
							</label>
						</section>
                      <section class=\"col col-4\">
                        <label class=\"input\">
                          <input type=\"text\" name=\"city\" placeholder=\"City\" disabled value=".$row['Emp_City'].">
                        </label>
                      </section>
                      <section class=\"col col-3\">
                        <label class=\"input\">
                          <input type=\"text\" name=\"code\" placeholder=\"Post code\" disabled value=".$row['Emp_Code'].">
                        </label>
                      </section>
                    </div>
					
                    <section>
                      <label for=\"file\" class=\"input\">
                        <input type=\"text\" name=\"address\" placeholder=\"Address\" disabled value=\"".htmlspecialchars($row['Emp_Address'])."\">
                      </label>
                    </section>
                    <section>
                      <label class=\"textarea\">
                        <textarea rows=\"3\" name=\"info\" placeholder=\"Additional info\" disabled >".htmlspecialchars($row['Emp_Add_Info'])."</textarea>
                      </label>
                    </section>
                  </fieldset>
				  <fieldset>
				  <header>Business Details</header>
				  <br>
                    <section>
                      <label class=\"input\">
                        <input type=\"text\" name=\"emp_salary\" placeholder=\"Business Name\" disabled value=".$row['Emp_Salary'].">
                      </label>
                    </section>
                    <section>
                      <label class=\"input\">
                        <input type=\"text\" name=\"emp_post\" placeholder=\"Business Address\" disabled value=".$row['Emp_Post'].">
                      </label>
                    </section>
                  </fieldset>
                  <footer>
                    <button type=\"submit\" class=\"btn btn-danger\">Delete Employee</button>
                  </footer>";
}
?>