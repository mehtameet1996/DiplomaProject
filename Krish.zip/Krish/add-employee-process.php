<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
if(isset($_POST['fname']))
{
	//retrieve all information from html page
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$gender = $_POST['gender'];
	$alt_phone = $_POST['alt_phone'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$code = $_POST['code'];
	$address = $_POST['address'];
	$info = $_POST['info'];
	$emp_salary = $_POST['salary'];
	$emp_post = $_POST['emp_post'];
	echo "fname = ".$fname ."<br>";
	echo "lname = ".$lname ."<br>";
	echo "email = ".$email ."<br>";
	echo "phone = ".$phone ."<br>";
	echo "gender = ".$gender ."<br>";
	echo "alt_phone = ".$alt_phone ."<br>";
	echo "state = ".$state ."<br>";
	echo "city = ".$city ."<br>";
	echo "code = ".$code ."<br>";
	echo "address = ".$address ."<br>";
	echo "info = ".$info ."<br>";
	echo "Salary = ".$emp_salary ."<br>";
	echo "post = ".$emp_post ."<br>";
	//Inserting data into database
	
	$result = mysqli_query($mysqli, "SELECT max(Emp_ID) as id FROM employee");
	$row = mysqli_fetch_array($result);
	if(is_null($row['id']))
	{
		$emp_id=1;
	}
	else
	{	
		$emp_id=$row['id'] + 1;
	}
	echo "cust_id = ".$emp_id;
	if ($insert_stmt = $mysqli->prepare("INSERT INTO employee VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,? ,?, ? )")) 
	{
		$insert_stmt->bind_param('dsssssssssssss', $emp_id, $fname, $lname,$email,$phone,$gender,$alt_phone,$state,$city,$code,$address,$info, $emp_salary, $emp_post);
		// Execute the prepared query.
		if ($insert_stmt->execute()) 
		{
			header('Location: customer-success.php');
		}
	}
}
?>
