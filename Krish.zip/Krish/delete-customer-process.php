<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
	//retrieve all information from html page
	$cust_name = strval($_POST['cust_name']);
	$name = explode(" ", $cust_name);
	//Inserting data into database
	$result = mysqli_query($mysqli, "SELECT Cust_ID FROM customers where Cust_FName='".$name[0]."' and Cust_LName='".$name[1]."'");
	$row = mysqli_fetch_array($result);
	$cust_id=$row['Cust_ID'];
	echo "cust_id = ".$cust_id;
	if ($insert_stmt = $mysqli->prepare("Delete from customers  where Cust_ID=?")) 
	{
		$insert_stmt->bind_param('d', $cust_id);
		// Execute the prepared query.
		if ($insert_stmt->execute()) 
		{
			header('Location: customer-success.php');
		}
	}
?>
