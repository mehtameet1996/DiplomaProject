﻿<!DOCTYPE html>
<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
function makecomma($input)
{
	if(strlen($input)<=2)
		return $input;
	$length = substr($input, 0 ,strlen($input)-2);
	$formatted_input = makecomma($length).",".substr($input, -2);
	return $formatted_input;
}
function formatIndianStyle($num)
{
	$pos = strpos((string)$num, ".");
	if($pos === false )
		$decimalpart="00";
	else
	{
		$decimalpart = substr($num, $pos+1, 2);
		$num = substr($num, 0, $pos);
	}
	if(strlen($num)>3 && strlen($num)<=12)
	{
		$last3digits = substr($num, -3);
		$numexceptlastdigits = substr($num,0, -3);
		$formatted = makecomma($numexceptlastdigits);
		$stringtoreturn = $formatted.",".$last3digits.".".$decimalpart;
	}
	elseif(strlen($num)<=3)
		$stringtoreturn = $num.".".$decimalpart;
	elseif(strlen($num)>12)
		$stringtoreturn = number_format($num, 2);
	if(substr($stringtoreturn, 0, 2)=="-,")
	{
		$stringtoreturn ="-".substr($stringtoreturn, 2);
	}
	return $stringtoreturn;
}

?>
<head>
<title>White Graphics - Invoice</title>
<link href="css/styles.css" rel="stylesheet" type="text/css">

<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
<script type="text/javascript" src="js/vendors/modernizr/modernizr.custom.js"></script>
<style type="text/css">
	#printable {display: none;}
	@media print
	{
		html{background: none; padding: 0;}
		body{box-shadow: none; padding: 0;}
		#non-printable 
		{
			display: none;
		}
		#printable
		{
			display: block;
		}
	}
	@page{
		size: 8.5in 11in;
		margin: 0;
	}
</style>
</head>

<body>
<?php
	$invoice_num = $_GET['invoice'];
	$result = mysqli_query($mysqli, "SELECT * FROM invoice where Invoice_Number=".$invoice_num);
	$result1 = mysqli_query($mysqli, "SELECT * FROM sales where Invoice_Number=".$invoice_num);
	$row1 = mysqli_fetch_array($result1);
	$cust_name = $row1['Customer_Name'];
?>
<!--Smooth Scroll-->
<div class="smooth-overflow">
<!--Navigation-->
    <nav class="main-header clearfix " role="navigation" id="non-printable"> 
	<a class="navbar-brand" href="index.php"><span class="text-blue">CMS</span></a> 
    
    <!--Search-->
    <div class="site-search" id="non-printable">
      <form action="#" id="inline-search">
        <i class="fa fa-search"></i>
        <input type="search" placeholder="Search">
      </form>
    </div>
    
    <!--Navigation Itself-->
    
    <div class="navbar-content" id="non-printable"> 
      <!--Fullscreen Trigger-->
      <button type="button" class="btn btn-default hidden-xs pull-right" id="toggle-fullscreen"> <i class=" entypo-popup"></i> </button>      
    </div>
  </nav>
    
    <!--/Navigation--> 
    
    <!--MainWrapper-->
    <div class="main-wrap"> 
      <!--Main Menu-->
    <div class="responsive-admin-menu" id="non-printable">
      <div class="responsive-menu">CMS
        <div class="menuicon"><i class="fa fa-angle-down"></i></div>
      </div>
      <ul id="menu">
        <li><a href="index.php" title="Dashboard">
		<i class="entypo-briefcase"></i><span> Dashboard</span></a></li>
        <li><a class="submenu" href="#" title="Customer" data-id="customers-sub">
			<i class="entypo-users"></i><span> Customers</span></a>
          <ul id="customers-sub">
            <li><a href="add-customers.php" title="Add Customers">
			<i class="entypo-user-add"></i><span> Add Customers</span></a></li>
            <li><a href="delete-customers.php" title="Delete Customers">
			<i class="entypo-cancel-circled"></i><span> Delete Customers</span></a></li>
			<li><a href="update-customers.php" title="Update Customers">
			<i class="entypo-retweet"></i><span> Update Customers</span></a></li>
			<li><a href="view-customers.php" title="View Customers">
			<i class="entypo-user"></i><span> View Customers</span></a></li>
          </ul>
        </li>
        <li><a href="#" class="submenu" data-id="suppliers-sub" title="Suppliers">
		<i class="fa fa-users"></i><span> Suppliers</span></a> 
          <!-- Tables Sub-Menu -->
          <ul id="suppliers-sub" class="accordion">
            <li><a href="add-supplier.php" title="Add Supplier">
			<i class="entypo-user-add"></i><span> Add Supplier</span></a></li>
            <li><a href="delete-supplier.php" title="Delete Supplier">
			<i class="entypo-cancel-circled"></i><span> Delete Supplier</span></a></li>
			<li><a href="update-supplier.php" title="Update Supplier">
			<i class="entypo-retweet"></i><span> Update Supplier</span></a></li>
			<li><a href="view-suppliers.php" title="View Suppliers">
			<i class="entypo-user"></i><span> View Suppliers</span></a></li>
          </ul>
        </li>
        <li><a class="submenu" href="#" data-id="employee-sub" title="Employee">
		<i class="fa fa-th"></i><span> Employee</span></a> 
          <!-- Forms Sub-Menu -->
          <ul id="employee-sub" class="accordion">
            <li><a href="add-employee.php" title="Add Employee">
			<i class="entypo-user-add"></i><span>Add Employee</span></a></li>
            <li><a href="delete-employee.php" title="Delete Employee">
			<i class="entypo-cancel-circled"></i><span>Delete Employee</span></a></li>
            <li><a href="update-employee.php" title="Update Employee">
			<i class="entypo-retweet"></i><span>Update Employee</span></a></li>
			<li><a href="pay-slip-employee.php" title="Generate Pay Slip">
			<i class="entypo-print"></i><span>Generate Pay Slip</span></a></li>
			<li><a href="view-employee.php" title="View Employee">
			<i class="entypo-user"></i><span> View Employee</span></a></li>
          </ul>
        <li> <a class="active" href="billing.php" title="Billing">
		<i class="entypo-chart-area"></i><span>Billing</span></a> 
		<li> <a href="send-mail.php" title="Send Mail">
		<i class="entypo-mail"></i><span>send-mail</span></a> 
          <!-- Graph and Charts Menu -->
		</ul>
    </div>
    <!--/MainMenu-->
      
      <div class="content-wrapper"> 
        <!--Content Wrapper-->
		<!--Horisontal Dropdown-->
        
        <!--Breadcrumb-->
        <div class="breadcrumb clearfix" id="non-printable">
          <ul>
            <li><a href="index.html"><i class="fa fa-home"></i></a></li>
            <li><a href="index.html">Dashboard</a></li>
            <li class="active">Invoice</li>
          </ul>
        </div>
        <!--/Breadcrumb-->
        
        <div class="page-header" id="non-printable">
          <h1>Page<small>Clear Page</small></h1>
        </div>
        
        <!-- Widget Row Start grid -->
        <div class="row" id="powerwidgets">
          <div class="col-md-12 bootstrap-grid"> 
            
            <!-- New widget -->
            <div class="powerwidget" id="forms-9" data-widget-editbutton="false">
              <header id="non-printable">
                <h2>Sample widget<small>Clear</small></h2>
              </header>
			  
              <div class="inner-spacer">
                <div class="invoice-block">
                  <div class="page-header">
                    <div class="logo-block"><img src="images/logo.png" alt="Logo" /></div>
						<h1>Invoice #<?php echo $invoice_num; ?></h1>
					</div>
                  <div class="well">
                    <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-6" >
                        <div class="from-to"><?php echo ($cust_name); ?></div>
						
                      </div>
                    </div>
                  </div>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th width="61%">Product/Product description</th>
                          <th width="5%">Qty</th>
                          <th width="12%">Unit Price &#8377;</th>
                          <th width="10%">Total &#8377;</th>
                        </tr>
                      </thead>
                      <tbody>
					  <?php
					  $i=0;
					  $total = 0;
					  while($row = mysqli_fetch_array($result))
					  {
						  $i++;
						  ?>
                        <tr>
                          <td><div class="product-name">
                              <div class="product-num"><?php echo $i;?></div>
                              <h4><?php echo $row['Particulars'];?></h4>
                              </div></td>
                          <td><?php echo $row['Quantity'];?></td>
                          <td><?php
							  echo ($row['Rate']);
						  ?>
						  </td>
                          <td><?php 
						  $total = $total + floatval(str_replace(",", "", $row['Amount']));
						  echo $row['Amount']; ?></td>
                        </tr>
						<?php
					  }
						?>
                        <tr>
                      </tbody>
                      <tfoot>
                      <td class="noborders" colspan="1" rowspan="3">&nbsp;</td>
                        <td colspan="2">Sub - Total</td>
                        <td colspan="2"><?php 
						echo  formatIndianStyle($total); ?></td>
                      </tr>
                      <tr>
                        <td colspan="2">VAT @ 5%</td>
                        <td colspan="2"><?php
						$vat = ($total*5)/100;
						echo formatIndianStyle($vat);
						?>
						</td>
                      </tr>
                      <tr>
                        <td colspan="2">Grand Total &#8377;</td>
                        <td colspan="2"><?php
						$grand_total = $total + $vat;
						echo formatIndianStyle($grand_total);
						?>
						</td>
                      </tr>
                        </tfoot>
                      
                    </table>
                    <div class="row">
                      <div class="col-lg-12 remittance">
                        <h5>Please remit payment to:</h5>
                        <ul>
                          <li>White Graphics</li>
                          <li>VAT No: 11 71 60 08</li>
                          <li>CST/TIN No: DE04 3003 0880 0011 7160 08</li>
                          <li>Bank Name: XYZ Bank</li>
                          <li>Bank Account Number: 15 - digit Bank Account Num</li>
						  <li>Bank IFSC Code: Branch Identification Code</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- /End Widget --> 
            
          </div>
          <!-- /Inner Row Col-md-12 --> 
        </div>
        <!-- /Widgets Row End Grid--> 
      </div>
      <!-- / Content Wrapper --> 
    </div>
    <!--/MainWrapper--> 
  </div>
<!--/Smooth Scroll--> 
<!--Modals--> 

<!--Sign Out Dialog Modal-->
<div class="modal" id="signout">
  <div class="modal-dialog modal-sm">
    <div class="modal-content" id="non-printable">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <i class="fa fa-lock"></i> </div>
      <div class="modal-body text-center">Are You Sure Want To Sign Out?</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" id="yesigo">Ok</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
    <!-- /.modal-content --> 
  </div>
  <!-- /.modal-dialog --> 
</div>
<!-- /.modal --> 

<!--Lock Screen Dialog Modal-->
<div class="modal" id="lockscreen">
  <div class="modal-dialog modal-sm" id="non-printable">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <i class="fa fa-lock"></i> </div>
      <div class="modal-body text-center">Are You Sure Want To Lock Screen?</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" id="yesilock">Ok</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
    <!-- /.modal-content --> 
  </div>
  <!-- /.modal-dialog --> 
</div>
<!-- /.modal --> 

<!--Scripts--> 
<!--JQuery--> 
<script type="text/javascript" src="js/vendors/jquery/jquery.min.js"></script> 
<script type="text/javascript" src="js/vendors/jquery/jquery-ui.min.js"></script> 
<script>
$('.powerwidget > header').on('touchstart', function(event){});
</script>

<!--Fullscreen--> 
<script type="text/javascript" src="js/vendors/fullscreen/screenfull.min.js"></script> 


<!--Horizontal Dropdown--> 
<script type="text/javascript" src="js/vendors/horisontal/cbpHorizontalSlideOutMenu.js"></script> 
<script type="text/javascript" src="js/vendors/classie/classie.js"></script> 

<!--PowerWidgets--> 
<script type="text/javascript" src="js/vendors/powerwidgets/powerwidgets.min.js"></script> 

<!--Bootstrap--> 
<script type="text/javascript" src="js/vendors/bootstrap/bootstrap.min.js"></script> 

<!--Main App--> 
<script type="text/javascript" src="js/scripts.js"></script>

<!--Sparkline--> 
<script type="text/javascript" src="js/vendors/sparkline/jquery.sparkline.min.js"></script> 

<!--/Scripts-->

</body>
</html>