<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
	//retrieve all information from html page
	$emp_name = strval($_POST['emp_name']);
	$name = explode(" ", $emp_name);
	//Inserting data into database
	$result = mysqli_query($mysqli, "SELECT Emp_ID FROM employee where Emp_FName='".$name[0]."' and Emp_LName='".$name[1]."'");
	$row = mysqli_fetch_array($result);
	$emp_id=$row['Emp_ID'];
	echo "emp_id = ".$emp_id;
	if ($insert_stmt = $mysqli->prepare("Delete from employee  where Emp_ID=?")) 
	{
		$insert_stmt->bind_param('d', $emp_id);
		// Execute the prepared query.
		if ($insert_stmt->execute()) 
		{
			header('Location: employee-success.php');
		}
	}
?>
