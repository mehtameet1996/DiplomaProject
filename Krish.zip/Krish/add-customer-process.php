<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
if(isset($_POST['fname']))
{
	//retrieve all information from html page
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$gender = $_POST['gender'];
	$alt_phone = $_POST['alt_phone'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$code = $_POST['code'];
	$address = $_POST['address'];
	$info = $_POST['info'];
	$business_name = $_POST['business_name'];
	$business_address = $_POST['business_address'];
	$b_email = $_POST['b_email'];
	$b_phone = $_POST['b_phone'];
	echo "fname = ".$fname ."<br>";
	echo "lname = ".$lname ."<br>";
	echo "email = ".$email ."<br>";
	echo "phone = ".$phone ."<br>";
	echo "gender = ".$gender ."<br>";
	echo "alt_phone = ".$alt_phone ."<br>";
	echo "state = ".$state ."<br>";
	echo "city = ".$city ."<br>";
	echo "code = ".$code ."<br>";
	echo "address = ".$address ."<br>";
	echo "info = ".$info ."<br>";
	echo "business_name = ".$business_name ."<br>";
	echo "business_address = ".$business_address ."<br>";
	echo "b_email = ".$b_email ."<br>";
	echo "b_phone = ".$b_phone ."<br>";
	//Inserting data into database
	$result = mysqli_query($mysqli, "SELECT max(Cust_ID) as id FROM customers");
	$row = mysqli_fetch_array($result);
	if(is_null($row['id']))
	{
		$cust_id=1;
	}
	else
	{	
		$cust_id=$row['id'] + 1;
	}
	echo "cust_id = ".$cust_id;
	if ($insert_stmt = $mysqli->prepare("INSERT INTO customers VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,? ,? ,? ,?)")) 
	{
		$insert_stmt->bind_param('dsssssssssssssss', $cust_id, $fname, $lname,$email,$phone,$gender,$alt_phone,$state,$city,$code,$address,$info, $business_name, $business_address, $b_email, $b_phone);
		// Execute the prepared query.
		if ($insert_stmt->execute()) 
		{
			header('Location: customer-success.php');
		}
	}
}
?>
