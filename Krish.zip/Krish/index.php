﻿<!DOCTYPE html>

<head>
<title>White Graphics - CMS</title>
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
<script type="text/javascript" src="js/vendors/modernizr/modernizr.custom.js"></script>
</head>

<body>

<!--Smooth Scroll-->
<div class="smooth-overflow">
<!--Navigation-->
  <nav class="main-header clearfix" role="navigation"> <a class="navbar-brand" href="index.php"><span class="text-blue">CMS</span></a> 
    
    
    <!--Navigation Itself-->
    
    <div class="navbar-content"> 
      <!--Fullscreen Trigger-->
      <button type="button" class="btn btn-default hidden-xs pull-right" id="toggle-fullscreen"> <i class=" entypo-popup"></i> </button>      
    </div>
  </nav>
  
  <!--/Navigation--> 
  
  <!--MainWrapper-->
  <div class="main-wrap"> 
    <!--Main Menu-->
    <div class="responsive-admin-menu">
      <div class="responsive-menu">ORB
        <div class="menuicon"><i class="fa fa-angle-down"></i></div>
      </div>
      <ul id="menu">
        <li><a class="active" href="index.php" title="Dashboard"><i class="entypo-briefcase"></i><span> Dashboard</span></a></li>
        <li><a class="submenu" href="#" title="Customer" data-id="customers-sub">
			<i class="entypo-users"></i><span> Customers</span></a>
          <ul id="customers-sub">
            <li><a href="add-customers.php" title="Add Customers">
			<i class="entypo-user-add"></i><span> Add Customers</span></a></li>
            <li><a href="delete-customers.php" title="Delete Customers">
			<i class="entypo-cancel-circled"></i><span> Delete Customers</span></a></li>
			<li><a href="update-customers.php" title="Update Customers">
			<i class="entypo-retweet"></i><span> Update Customers</span></a></li>
			<li><a href="view-customers.php" title="View Customers">
			<i class="entypo-user"></i><span> View Customers</span></a></li>
          </ul>
        </li>
        <li><a href="#" class="submenu" data-id="suppliers-sub" title="Suppliers">
		<i class="fa fa-users"></i><span> Suppliers</span></a> 
          <!-- Tables Sub-Menu -->
          <ul id="suppliers-sub" class="accordion">
            <li><a href="add-supplier.php" title="Add Supplier">
			<i class="entypo-user-add"></i><span> Add Supplier</span></a></li>
            <li><a href="delete-supplier.php" title="Delete Supplier">
			<i class="entypo-cancel-circled"></i><span> Delete Supplier</span></a></li>
			<li><a href="update-supplier.php" title="Update Supplier">
			<i class="entypo-retweet"></i><span> Update Supplier</span></a></li>
			<li><a href="view-suppliers.php" title="View Suppliers">
			<i class="entypo-user"></i><span> View Suppliers</span></a></li>
          </ul>
        </li>
        <li><a class="submenu" href="#" data-id="employee-sub" title="Employee">
		<i class="fa fa-th"></i><span> Employee</span></a> 
          <!-- Forms Sub-Menu -->
          <ul id="employee-sub" class="accordion">
            <li><a href="add-employee.php" title="Add Employee">
			<i class="entypo-user-add"></i><span>Add Employee</span></a></li>
            <li><a href="delete-employee.php" title="Delete Employee">
			<i class="entypo-cancel-circled"></i><span>Delete Employee</span></a></li>
            <li><a href="update-employee.php" title="Update Employee">
			<i class="entypo-retweet"></i><span>Update Employee</span></a></li>
			<li><a href="view-employee.php" title="View Employee">
			<i class="entypo-user"></i><span> View Employee</span></a></li>
          </ul>
        <li> <a href="billing.php" title="Billing">
		<i class="entypo-chart-area"></i><span>Billing</span></a> 
		<li> <a href="send-mail.php" title="Send Mail">
		<i class="entypo-mail"></i><span>send-mail</span></a> 
          <!-- Graph and Charts Menu -->
		</ul>
    </div>
    <!--/MainMenu-->
    
    <div class="content-wrapper"> 
      <!--Content Wrapper--><!--Horisontal Dropdown-->
        <nav class="cbp-hsmenu-wrapper" id="cbp-hsmenu-wrapper">
        </nav>
        
        
          <!--Breadcrumb-->
<div class="breadcrumb clearfix">
            <ul>
              <li><a href="index.php"><i class="fa fa-home"></i></a></li>
              <li><a href="index.php">Dashboard</a></li>
              <li class="active">Data</li>
            </ul>
          </div>
          <!--/Breadcrumb--> 
          
          <!--Jumbotron-->
          <div class="jumbotron jumbotron0">
            <h1>Welcome 2 <strong>CMS</strong></h1>
            <p class="lead">CMS &#8212; fully responsive admin website. 
              CMS is packed with all features that can be used in 
              business world. Such as Dealing with customers or it might be suppliers.
			Includes a good invoice with tax calculation</p>
            <small>CMS has been developed by SAKP students with internship at White Graphics as a 3rd Year Project</small>
          </div>
          <!--/Jumbotron--> 
        </div>
      <!-- / Content Wrapper --> 
    </div>
    <!--/MainWrapper-->
</div>
<!--/Smooth Scroll--> 

<!--Scripts--> 
<!--JQuery--> 
<script type="text/javascript" src="js/vendors/jquery/jquery.min.js"></script> 
<script type="text/javascript" src="js/vendors/jquery/jquery-ui.min.js"></script> 

<script>
$('.powerwidget > header').on('touchstart', function(event){});
</script>

<!--EasyPieChart--> 
<script type="text/javascript" src="js/vendors/easing/jquery.easing.1.3.min.js"></script> 
<script type="text/javascript" src="js/vendors/easypie/jquery.easypiechart.min.js"></script> 

<!--Fullscreen--> 
<script type="text/javascript" src="js/vendors/fullscreen/screenfull.min.js"></script> 

<!--NanoScroller--> 
<script type="text/javascript" src="js/vendors/nanoscroller/jquery.nanoscroller.min.js"></script> 

<!--Sparkline--> 
<script type="text/javascript" src="js/vendors/sparkline/jquery.sparkline.min.js"></script> 

<!--Horizontal Dropdown--> 
<script type="text/javascript" src="js/vendors/horisontal/cbpHorizontalSlideOutMenu.js"></script> 
<script type="text/javascript" src="js/vendors/classie/classie.js"></script> 

<!--PowerWidgets--> 
<script type="text/javascript" src="js/vendors/powerwidgets/powerwidgets.min.js"></script> 

<!--Morris Chart--> 
<script type="text/javascript" src="js/vendors/raphael/raphael-min.js"></script> 
<script type="text/javascript" src="js/vendors/morris/morris.min.js"></script> 

<!--FlotChart--> 
<script type="text/javascript" src="js/vendors/flotchart/jquery.flot.min.js"></script> 
<script type="text/javascript" src="js/vendors/flotchart/jquery.flot.resize.min.js"></script> 
<script type="text/javascript" src="js/vendors/flotchart/jquery.flot.axislabels.js"></script> 

<!--Chart.js--> 
<script type="text/javascript" src="js/vendors/chartjs/chart.min.js"></script> 

<!--Calendar--> 
<script type="text/javascript" src="js/vendors/fullcalendar/fullcalendar.min.js"></script> 
<script type="text/javascript" src="js/vendors/fullcalendar/gcal.js"></script> 

<!--Bootstrap--> 
<script type="text/javascript" src="js/vendors/bootstrap/bootstrap.min.js"></script> 

<!--Vector Map--> 
<script type="text/javascript" src="js/vendors/vector-map/jquery.vmap.min.js"></script> 
<script type="text/javascript" src="js/vendors/vector-map/jquery.vmap.sampledata.js"></script> 
<script type="text/javascript" src="js/vendors/vector-map/jquery.vmap.world.js"></script> 

<!--ToDo--> 
<script type="text/javascript" src="js/vendors/todos/todos.js"></script> 

<!--Main App--> 
<script type="text/javascript" src="js/scripts.js"></script>



<!--/Scripts-->

</body>
</html>