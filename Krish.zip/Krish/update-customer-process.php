<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
	//retrieve all information from html page
	$cust = strval($_POST['cust_name']);
	$name = explode(" ", $cust);
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$alt_phone = $_POST['alt_phone'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$code = $_POST['code'];
	$address = $_POST['address'];
	$info = $_POST['info'];
	$business_name = $_POST['business_name'];
	$business_address = $_POST['business_address'];
	$b_email = $_POST['b_email'];
	$b_phone = $_POST['b_phone'];
	echo "fname = ".$name[0] ."<br>";
	echo "lname = ".$name[1] ."<br>";
	echo "email = ".$email ."<br>";
	echo "phone = ".$phone ."<br>";
	echo "alt_phone = ".$alt_phone ."<br>";
	echo "state = ".$state ."<br>";
	echo "city = ".$city ."<br>";
	echo "code = ".$code ."<br>";
	echo "address = ".$address ."<br>";
	echo "info = ".$info ."<br>";
	echo "business_name = ".$business_name ."<br>";
	echo "business_address = ".$business_address ."<br>";
	echo "b_email = ".$b_email ."<br>";
	echo "b_phone = ".$b_phone ."<br>";
	//Inserting data into database
	$result = mysqli_query($mysqli, "SELECT Cust_ID FROM customers where Cust_FName='".$name[0]."' and Cust_LName='".$name[1]."'");
	$row = mysqli_fetch_array($result);
	$cust_id=$row['Cust_ID'];
	echo "cust_id = ".$cust_id;
	if ($insert_stmt = $mysqli->prepare("Update customers set Cust_Email=?, Cust_Phone=?, Cust_Alt_Phone=?, Cust_State=?, Cust_City=?, Cust_Code=?, Cust_Address=?, Cust_Add_Info=?, Business_Name=?, Business_Address=?, Business_Email=?, Business_Phone=? where Cust_ID=".$cust_id)) 
	{
		$insert_stmt->bind_param('ssssssssssss', $email, $phone, $alt_phone, $state, $city, $code, $address, $info, $business_name, $business_address, $b_email, $b_phone);
		// Execute the prepared query.
		if ($insert_stmt->execute()) 
		{
			header('Location: customer-success.php');
		}
	}
?>
