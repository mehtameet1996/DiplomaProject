<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

	//retrieve all information from html page
	$cust_name = $_POST['cust_name'];
	$particulars = $_POST['particulars'];
	$quantity = $_POST['quantity'];
	$rate = $_POST['rate'];
	$amount = $_POST['amount'];
	
	$par_count = count($particulars);
	$quantity_count = count($quantity);
	$rate_count = count($rate);
	$amount_count = count($amount);
	echo $par_count;
	echo $quantity_count;
	echo $rate_count;
	echo $amount_count;
	
	echo $cust_name."<br>";
	
	for($i=0; $i<$par_count; $i++)
		echo($particulars[$i]."<br>");
	
	for($i=0;$i<$quantity_count;$i++)
		echo($quantity[$i]."<br>");
	
	for($i=0;$i<$rate_count;$i++)
		echo($rate[$i]."<br>");
	
	for($i=0;$i<$amount_count;$i++)
		echo($amount[$i]."<br>");
	
	
	//Inserting data into database
	
	$result = mysqli_query($mysqli, "SELECT max(Invoice_Number) as id FROM invoice");
	$row = mysqli_fetch_array($result);
	if(is_null($row['id']))
	{
		$invoice_num=1;
	}
	else
	{	
		$invoice_num=$row['id'] + 1;
	}
	if ($insert_stmt = $mysqli->prepare("INSERT INTO sales VALUES (?, ?)")) 
	{
		$insert_stmt->bind_param('ds', $invoice_num, $cust_name);
		// Execute the prepared query.
		if ($insert_stmt->execute()) 
		{
			//header('Location: customer-success.php');
		}
	}
	for($i=0; $i<$par_count; $i++)
	{
		if ($insert_stmt = $mysqli->prepare("INSERT INTO invoice VALUES (?, ?, ?, ?, ?)")) 
		{
			$insert_stmt->bind_param('dssss', $invoice_num, $particulars[$i], $quantity[$i], $rate[$i],$amount[$i]);
			// Execute the prepared query.
			if ($insert_stmt->execute()) 
			{
				//header('Location: customer-success.php');
			}
		}
	}
	header('Location: invoice.php?invoice='.$invoice_num);
?>
