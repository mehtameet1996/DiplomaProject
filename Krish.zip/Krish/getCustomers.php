<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

$sql="SELECT * FROM customers";
$result = mysqli_query($mysqli,$sql);
echo"<option value=\"0\" selected disabled>Select Customer Name</option>";
while($row = mysqli_fetch_array($result))
  {
	  
	echo"<option value=\"".$row['Cust_FName']." ".$row['Cust_LName']."\">".$row['Cust_FName']." ".$row['Cust_LName']."</option>";
  }
?>