<?php
include 'Mail.php';
include 'Mail/mime.php' ;
$crlf = "\n";
$mime = new Mail_mime(array('eol' => $crlf));
$to = $_POST['to'];
$from = $_POST['from'];
$body = $_POST['body'];
$sub = $_POST['subject'];
/*$mime->addHTMLimage('img/twitter.png', 'image/png');
$mime->addHTMLimage('img/facebook.png', 'image/png');
$mime->addHTMLimage('img/windows.png', 'image/png');
$mime->addHTMLimage('img/delicious.png', 'image/png');
$mime->addHTMLimage('img/flickr.png', 'image/png');
$mime->addHTMLimage('img/linkedin.png', 'image/png');
$mime->addHTMLimage('img/skype.png', 'image/png');
$mime->addHTMLimage('img/stumbleupon.png', 'image/png');
$mime->addHTMLimage('img/vimeo.png', 'image/png');
$mime->addHTMLimage('img/contact.png', 'image/png');
$mime->addHTMLimage('img/overview.jpg', 'image/jpg');
$mime->addHTMLimage('img/logo.png', 'image/png');*/

//$text = 'Text version of email';
$html = $body;

$hdrs = array(
              'From'=>$from,
              'Subject'=>$sub,
              'MIME-Version'=>'1.0',
              'Content-Type'=>'css/html; charset=ISO-8859-1'
              );

//$mime->setTXTBody($text);
$mime->setHTMLBody($html);
$body = $mime->get();
$hdrs = $mime->headers($hdrs);
$mail =& Mail::factory('mail');
$mail->send($to, $hdrs, $body);
?>