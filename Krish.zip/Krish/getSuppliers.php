<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

$sql="SELECT * FROM supplier";
$result = mysqli_query($mysqli,$sql);
echo"<option value=\"0\" selected disabled>Select Supplier Name</option>";
while($row = mysqli_fetch_array($result))
  {
	  
	echo"<option value=\"".$row['Supp_FName']." ".$row['Supp_LName']."\">".$row['Supp_FName']." ".$row['Supp_LName']."</option>";
  }
?>